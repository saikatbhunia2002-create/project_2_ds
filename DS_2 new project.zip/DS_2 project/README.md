# Sentinel — Network Intrusion Detection

A local web app for training and comparing binary network-traffic classifiers. It includes a responsive HTML/CSS/JavaScript interface and a Flask/scikit-learn backend.

## Run locally

Use Python 3.10 or later:

```powershell
py -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python app.py
```

Open [http://127.0.0.1:5000](http://127.0.0.1:5000). Uploaded CSV data and saved model files stay on the local machine.

Open the app through Flask at [http://127.0.0.1:5000](http://127.0.0.1:5000). If you open `index.html` through VS Code Live Server on port 5500, it redirects to Flask so requests remain same-origin and do not require CORS.

## Train a model

1. Upload a labeled CSV (up to 200 MB). The page summarizes row/column counts, missing values, duplicates, feature types, and candidate binary targets.
2. Select the target and a training sample limit. `label` is preferred when present; `attack_cat` is also supported.
3. Start training. The app creates an 80/20 stratified train/test split, preprocesses numeric and categorical features within each estimator pipeline, and tunes Logistic Regression, Decision Tree, and Random Forest using stratified cross-validation with up to 5 folds.
4. Models are ranked by mean validation F1 for the malicious class. The page shows cross-validation folds, tuned parameters, test metrics, class-level reports, and confusion matrices.
5. After training, fill in the generated feature form to classify a new record.

For UNSW-NB15 binary labels, `0`/`Normal` is treated as normal traffic and `1`/other attack categories as malicious. The feature pipeline excludes the selected target, known target-derived columns (`label`, `attack_cat`, `target`, `class`, `is_attack`), and common flow/IP identifiers. Blank feature inputs are imputed using values learned from the training split.

The default sample limit is 10,000 rows to keep cross-validation grid searches manageable. Increase it for more data if your machine has sufficient memory and CPU. Each class must have at least 3 records; the fold count is reduced when a class has fewer than 5 training examples.

## Saved files

Training writes these files under `artifacts/`:

- `model_bundle.joblib` — all three tuned pipelines and the selected pipeline.
- `best_model.joblib` — the selected preprocessing-and-classification pipeline.
- `training_report.json` — metrics, validation scores, parameters, and feature metadata.

Do not load joblib files from untrusted sources. The web service binds to localhost by default.
