from __future__ import annotations

import json
import logging
import os
import tempfile
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
from flask import Flask, jsonify, render_template, request, send_from_directory
from sklearn.compose import ColumnTransformer
from sklearn.ensemble import RandomForestClassifier
from sklearn.impute import SimpleImputer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
)
from sklearn.model_selection import GridSearchCV, StratifiedKFold, train_test_split
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import OneHotEncoder, StandardScaler
from sklearn.tree import DecisionTreeClassifier


BASE_DIR = Path(__file__).resolve().parent
ARTIFACT_DIR = BASE_DIR / "artifacts"
MAX_UPLOAD_BYTES = 200 * 1024 * 1024
MAX_TRAINING_SAMPLES = 50_000
TARGET_NAMES = {"label", "attack_cat", "target", "class", "is_attack"}
IDENTIFIER_NAMES = {"id", "flow_id", "srcip", "dstip", "source_ip", "destination_ip"}
NORMAL_LABELS = {"normal", "normal traffic", "benign", "legitimate", "0", "0.0", "false", "no"}

app = Flask(__name__, template_folder=str(BASE_DIR), static_folder=None)
app.config["MAX_CONTENT_LENGTH"] = MAX_UPLOAD_BYTES
app.logger.setLevel(logging.INFO)


def clean_columns(frame: pd.DataFrame) -> pd.DataFrame:
    frame.columns = [str(column).strip() for column in frame.columns]
    if frame.columns.duplicated().any():
        raise ValueError("The CSV contains duplicate column names after trimming whitespace.")
    if not len(frame.columns):
        raise ValueError("The CSV does not contain any columns.")
    return frame


def read_uploaded_csv(file_storage: Any) -> pd.DataFrame:
    if file_storage is None or not file_storage.filename:
        raise ValueError("Choose a CSV file first.")
    if Path(file_storage.filename).suffix.lower() != ".csv":
        raise ValueError("The uploaded file must have a .csv extension.")
    try:
        frame = pd.read_csv(file_storage.stream, low_memory=False)
    except (UnicodeDecodeError, pd.errors.ParserError, pd.errors.EmptyDataError) as error:
        raise ValueError(f"Could not read the CSV: {error}") from error
    if frame.empty:
        raise ValueError("The uploaded CSV has no data rows.")
    return clean_columns(frame)


def is_normal_label(value: Any) -> bool:
    text = str(value).strip().lower()
    if text in NORMAL_LABELS:
        return True
    try:
        return float(text) == 0
    except (TypeError, ValueError):
        return text.startswith("normal ") or text.startswith("benign ")


def encode_target(values: pd.Series) -> pd.Series:
    usable = values.dropna()
    if usable.nunique() < 2:
        raise ValueError("The selected target must contain at least two classes.")
    classes = list(pd.unique(usable))
    normal_values = [value for value in classes if is_normal_label(value)]
    if len(normal_values) != 1:
        raise ValueError(
            "The target needs an identifiable normal/benign class (or numeric 0); all other classes are treated as attacks."
        )
    normal_value = normal_values[0]
    encoded = values.map(lambda value: np.nan if pd.isna(value) else int(value != normal_value))
    return encoded.astype("Int64")


def target_options(frame: pd.DataFrame) -> tuple[list[dict[str, Any]], str | None]:
    recognized = [column for column in frame.columns if column.lower() in TARGET_NAMES]
    remaining = [
        column for column in frame.columns
        if column not in recognized and column.lower() not in IDENTIFIER_NAMES
    ]
    candidates = recognized + remaining
    options: list[dict[str, Any]] = []
    seen: set[str] = set()
    for column in candidates:
        series = frame[column].dropna()
        if not 2 <= series.nunique() <= 20:
            continue
        try:
            labels = encode_target(frame[column])
        except ValueError:
            continue
        counts = labels.dropna().value_counts()
        if len(counts) != 2:
            continue
        options.append({
            "name": column,
            "counts": {
                "Normal": int(counts.get(0, 0)),
                "Malicious": int(counts.get(1, 0)),
            },
        })
        seen.add(column)
    options = [option for option in options if option["name"] in seen]
    preferred = next((name for name in ("label", "attack_cat") if name in seen), None)
    return options, preferred


def infer_feature_kind(series: pd.Series) -> str:
    return "numeric" if pd.api.types.is_numeric_dtype(series.dtype) else "categorical"


def build_feature_frame(
    frame: pd.DataFrame, target: str
) -> tuple[pd.DataFrame, list[str], list[str]]:
    excluded = {target.lower(), "label", "attack_cat", "target", "class", "is_attack"}
    excluded.update(IDENTIFIER_NAMES)
    columns = [column for column in frame.columns if column.lower() not in excluded]
    if not columns:
        raise ValueError("No usable input features remain after excluding the target and identifier columns.")
    features = frame.loc[:, columns].copy()
    numeric_columns = [
        column for column in columns if infer_feature_kind(features[column]) == "numeric"
    ]
    categorical_columns = [column for column in columns if column not in numeric_columns]
    for column in numeric_columns:
        features[column] = pd.to_numeric(features[column], errors="coerce")
        features[column] = features[column].replace([np.inf, -np.inf], np.nan)
    for column in categorical_columns:
        values = features[column]
        features[column] = values.map(
            lambda value: np.nan if pd.isna(value) else str(value).strip()
        )
    all_missing = [column for column in columns if features[column].isna().all()]
    if all_missing:
        features = features.drop(columns=all_missing)
        numeric_columns = [column for column in numeric_columns if column not in all_missing]
        categorical_columns = [column for column in categorical_columns if column not in all_missing]
    if features.empty or not features.columns.size:
        raise ValueError("No usable feature columns remain after cleaning missing values.")
    return features, numeric_columns, categorical_columns


def make_pipeline(
    numeric_columns: list[str], categorical_columns: list[str], classifier: Any
) -> Pipeline:
    transformers: list[tuple[str, Pipeline, list[str]]] = []
    if numeric_columns:
        numeric_pipeline = Pipeline([
            ("imputer", SimpleImputer(strategy="median")),
            ("scaler", StandardScaler(with_mean=False)),
        ])
        transformers.append(("numeric", numeric_pipeline, numeric_columns))
    if categorical_columns:
        categorical_pipeline = Pipeline([
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("onehot", OneHotEncoder(handle_unknown="ignore")),
        ])
        transformers.append(("categorical", categorical_pipeline, categorical_columns))
    preprocessor = ColumnTransformer(transformers, remainder="drop")
    return Pipeline([("preprocessor", preprocessor), ("classifier", classifier)])


def feature_metadata(
    features: pd.DataFrame, numeric_columns: list[str], categorical_columns: list[str]
) -> list[dict[str, Any]]:
    result = []
    for column in features.columns:
        is_numeric = column in numeric_columns
        categories: list[str] = []
        if not is_numeric:
            categories = [
                str(value) for value in features[column].value_counts().head(15).index.tolist()
            ]
        result.append({
            "name": column,
            "kind": "numeric" if is_numeric else "categorical",
            "categories": categories,
        })
    return result


def numeric_summaries(frame: pd.DataFrame) -> list[dict[str, Any]]:
    summaries = []
    for column in frame.select_dtypes(include="number").columns[:6]:
        values = pd.to_numeric(frame[column], errors="coerce").replace([np.inf, -np.inf], np.nan).dropna()
        if values.empty:
            continue
        summaries.append({
            "name": column,
            "min": float(values.min()),
            "median": float(values.median()),
            "max": float(values.max()),
        })
    return summaries


def json_safe(value: Any) -> Any:
    if isinstance(value, dict):
        return {str(key): json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(item) for item in value]
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, np.ndarray):
        return value.tolist()
    if isinstance(value, (np.bool_,)):
        return bool(value)
    return value


def save_artifacts(
    best_pipeline: Pipeline,
    best_model_name: str,
    models: dict[str, Pipeline],
    report: dict[str, Any],
) -> None:
    ARTIFACT_DIR.mkdir(parents=True, exist_ok=True)
    for filename, payload in (
        ("model_bundle.joblib", {
            "best_model": best_pipeline,
            "best_model_name": best_model_name,
            "models": models,
            "features": report["feature_info"],
        }),
        ("best_model.joblib", best_pipeline),
    ):
        with tempfile.NamedTemporaryFile(dir=ARTIFACT_DIR, suffix=".tmp", delete=False) as temporary:
            temporary_path = Path(temporary.name)
        try:
            joblib.dump(payload, temporary_path)
            temporary_path.replace(ARTIFACT_DIR / filename)
        finally:
            temporary_path.unlink(missing_ok=True)
    report_path = ARTIFACT_DIR / "training_report.json"
    report_path.write_text(json.dumps(report, indent=2), encoding="utf-8")


@app.get("/")
def home():
    return render_template("index.html")


@app.get("/<path:filename>")
@app.get("/assets/<path:filename>")
def assets(filename: str):
    if filename not in {"style.css", "script.js"}:
        return jsonify(error="Asset not found."), 404
    return send_from_directory(BASE_DIR, filename)


@app.get("/api/health")
def health():
    return jsonify(status="ok", model_saved=(ARTIFACT_DIR / "best_model.joblib").exists())


@app.post("/api/inspect")
def inspect_dataset():
    try:
        frame = read_uploaded_csv(request.files.get("file"))
        options, recommended = target_options(frame)
        columns = []
        for column in frame.columns:
            kind = infer_feature_kind(frame[column])
            columns.append({"name": column, "kind": kind})
        return jsonify({
            "filename": Path(request.files["file"].filename).name,
            "rows": int(len(frame)),
            "columns": columns,
            "target_options": options,
            "recommended_target": recommended,
            "missing_values": int(frame.isna().sum().sum()),
            "duplicate_rows": int(frame.duplicated().sum()),
            "numeric_columns": sum(column["kind"] == "numeric" for column in columns),
            "categorical_columns": sum(column["kind"] == "categorical" for column in columns),
            "numeric_summary": numeric_summaries(frame),
        })
    except ValueError as error:
        return jsonify(error=str(error)), 400
    except Exception as error:
        app.logger.exception("Dataset inspection failed")
        return jsonify(error=f"Dataset inspection failed: {error}"), 500


@app.post("/api/train")
def train_models():
    try:
        frame = read_uploaded_csv(request.files.get("file"))
        target = request.form.get("target", "").strip()
        if target not in frame.columns:
            raise ValueError("Choose a target column that exists in the uploaded CSV.")
        if target.lower() in IDENTIFIER_NAMES:
            raise ValueError("An identifier column cannot be used as the classification target.")

        try:
            max_samples = int(request.form.get("max_samples", "10000"))
        except ValueError as error:
            raise ValueError("The training sample limit must be a whole number.") from error
        if not 100 <= max_samples <= MAX_TRAINING_SAMPLES:
            raise ValueError(f"The training sample limit must be between 100 and {MAX_TRAINING_SAMPLES:,}.")

        encoded_target = encode_target(frame[target])
        valid_rows = encoded_target.notna()
        frame = frame.loc[valid_rows].reset_index(drop=True)
        y = encoded_target.loc[valid_rows].astype(int).reset_index(drop=True)
        if y.nunique() != 2:
            raise ValueError("Both normal and malicious target classes must have records.")
        if y.value_counts().min() < 3:
            raise ValueError(
                "Each class needs at least 3 records for a stratified train/test split and 2-fold validation."
            )

        if len(frame) > max_samples:
            frame, _, y, _ = train_test_split(
                frame,
                y,
                train_size=max_samples,
                stratify=y,
                random_state=42,
            )
            frame = frame.reset_index(drop=True)
            y = y.reset_index(drop=True)
        if y.value_counts().min() < 3:
            raise ValueError(
                "The selected sample contains fewer than 3 records from one class. Increase the sample limit or provide more examples of the minority class."
            )

        features, numeric_columns, categorical_columns = build_feature_frame(frame, target)
        if len(features) != len(y):
            raise ValueError("Some feature rows could not be aligned with the selected target.")
        X_train, X_test, y_train, y_test = train_test_split(
            features,
            y,
            test_size=0.2,
            stratify=y,
            random_state=42,
        )
        cv_folds = min(5, int(y_train.value_counts().min()))
        if cv_folds < 2:
            raise ValueError("The training split needs at least 2 records from each class for cross-validation.")

        folds = StratifiedKFold(n_splits=cv_folds, shuffle=True, random_state=42)
        specifications = [
            (
                "Logistic Regression",
                LogisticRegression(
                    max_iter=1000, class_weight="balanced", solver="liblinear", random_state=42
                ),
                {"classifier__C": [0.1, 1.0, 10.0]},
            ),
            (
                "Decision Tree",
                DecisionTreeClassifier(class_weight="balanced", random_state=42),
                {
                    "classifier__max_depth": [None, 16, 32],
                    "classifier__min_samples_leaf": [1, 3],
                },
            ),
            (
                "Random Forest",
                RandomForestClassifier(
                    class_weight="balanced_subsample", random_state=42, n_jobs=-1
                ),
                {
                    "classifier__n_estimators": [60, 100],
                    "classifier__max_depth": [None, 16],
                },
            ),
        ]
        tuned_models: dict[str, Pipeline] = {}
        results: list[dict[str, Any]] = []
        for name, classifier, parameter_grid in specifications:
            pipeline = make_pipeline(numeric_columns, categorical_columns, classifier)
            search = GridSearchCV(
                pipeline,
                parameter_grid,
                scoring="f1",
                cv=folds,
                n_jobs=1,
                refit=True,
                error_score="raise",
            )
            search.fit(X_train, y_train)
            model = search.best_estimator_
            predictions = model.predict(X_test)
            cv_results = search.cv_results_
            best_index = search.best_index_
            fold_scores = [
                float(cv_results[f"split{fold}_test_score"][best_index]) for fold in range(cv_folds)
            ]
            class_report = classification_report(
                y_test,
                predictions,
                labels=[0, 1],
                target_names=["Normal Traffic", "Malicious Traffic"],
                output_dict=True,
                zero_division=0,
            )
            results.append({
                "name": name,
                "cv_f1_mean": float(search.best_score_),
                "cv_f1_std": float(cv_results["std_test_score"][best_index]),
                "cv_f1_folds": fold_scores,
                "best_params": {
                    key.removeprefix("classifier__"): json_safe(value)
                    for key, value in search.best_params_.items()
                },
                "accuracy": float(accuracy_score(y_test, predictions)),
                "precision": float(precision_score(y_test, predictions, zero_division=0)),
                "recall": float(recall_score(y_test, predictions, zero_division=0)),
                "f1": float(f1_score(y_test, predictions, zero_division=0)),
                "confusion_matrix": confusion_matrix(y_test, predictions, labels=[0, 1]).tolist(),
                "classification_report": json_safe(class_report),
            })
            tuned_models[name] = model

        selected = max(results, key=lambda item: item["cv_f1_mean"])
        report: dict[str, Any] = {
            "best_model": selected["name"],
            "best_f1": selected["f1"],
            "best_cv_f1": selected["cv_f1_mean"],
            "target": target,
            "sampled_records": int(len(features)),
            "train_records": int(len(X_train)),
            "test_records": int(len(X_test)),
            "cv_folds": cv_folds,
            "feature_count": int(len(features.columns)),
            "feature_info": feature_metadata(features, numeric_columns, categorical_columns),
            "models": results,
        }
        report = json_safe(report)
        save_artifacts(tuned_models[selected["name"]], selected["name"], tuned_models, report)
        app.config["MODEL_BUNDLE"] = {
            "pipeline": tuned_models[selected["name"]],
            "features": report["feature_info"],
            "model_name": selected["name"],
        }
        return jsonify(report)
    except ValueError as error:
        return jsonify(error=str(error)), 400
    except Exception as error:
        app.logger.exception("Model training failed")
        return jsonify(error=f"Model training failed: {error}"), 500


@app.post("/api/predict")
def predict():
    bundle = app.config.get("MODEL_BUNDLE")
    if bundle is None and (ARTIFACT_DIR / "model_bundle.joblib").exists():
        try:
            saved = joblib.load(ARTIFACT_DIR / "model_bundle.joblib")
            model_name = saved["best_model_name"]
            bundle = {
                "pipeline": saved["best_model"],
                "features": saved["features"],
                "model_name": model_name,
            }
            app.config["MODEL_BUNDLE"] = bundle
        except Exception as error:
            app.logger.exception("Saved model could not be loaded")
            return jsonify(error=f"The saved model could not be loaded: {error}"), 500
    if bundle is None:
        return jsonify(error="Train a model before requesting a prediction."), 409

    try:
        payload = request.get_json(silent=True)
        if not isinstance(payload, dict) or not isinstance(payload.get("features"), dict):
            raise ValueError("Send a JSON object with a `features` object.")
        submitted = payload["features"]
        expected = bundle["features"]
        expected_names = [feature["name"] for feature in expected]
        unknown = set(submitted) - set(expected_names)
        if unknown:
            raise ValueError(f"Unknown feature name(s): {', '.join(sorted(unknown))}.")
        record: dict[str, Any] = {}
        for feature in expected:
            name = feature["name"]
            value = submitted.get(name)
            if value is None or value == "":
                record[name] = np.nan
            elif feature["kind"] == "numeric":
                try:
                    numeric_value = float(value)
                except (TypeError, ValueError) as error:
                    raise ValueError(f"`{name}` must be numeric.") from error
                if not np.isfinite(numeric_value):
                    raise ValueError(f"`{name}` must be a finite number.")
                record[name] = numeric_value
            else:
                record[name] = str(value).strip()
        sample = pd.DataFrame([record], columns=expected_names)
        prediction = int(bundle["pipeline"].predict(sample)[0])
        probabilities = bundle["pipeline"].predict_proba(sample)[0]
        confidence = float(probabilities[prediction])
        return jsonify({
            "prediction": prediction,
            "label": "Malicious Traffic" if prediction == 1 else "Normal Traffic",
            "confidence": confidence,
            "model": bundle["model_name"],
        })
    except ValueError as error:
        return jsonify(error=str(error)), 400
    except Exception as error:
        app.logger.exception("Prediction failed")
        return jsonify(error=f"Prediction failed: {error}"), 500


@app.errorhandler(413)
def request_too_large(_error: Any):
    return jsonify(error="The uploaded CSV is larger than the 200 MB limit."), 413


if __name__ == "__main__":
    port = int(os.environ.get("PORT", "5000"))
    app.run(host="127.0.0.1", port=port, debug=False)
