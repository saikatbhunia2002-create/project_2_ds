(() => {
  const $ = (selector) => document.querySelector(selector);
  const isLiveServer = ["localhost", "127.0.0.1"].includes(window.location.hostname)
    && window.location.port === "5500";
  if (isLiveServer) {
    window.location.replace("http://127.0.0.1:5000/");
    return;
  }
  const API_BASE = "";
  const state = { file: null, columns: [], target: null, trained: false };
  const elements = {
    file: $("#dataset-file"),
    dropZone: $("#drop-zone"),
    target: $("#target-select"),
    sampleSize: $("#sample-size"),
    train: $("#train-button"),
    overlay: $("#loading-overlay"),
    loadingMessage: $("#loading-message"),
    toastRegion: $("#toast-region")
  };

  const number = (value) => new Intl.NumberFormat().format(value);
  const percent = (value) => `${(Number(value) * 100).toFixed(1)}%`;
  const escapeHtml = (value) => String(value).replace(/[&<>"']/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
  })[character]);

  function showToast(message, type = "error") {
    const toast = document.createElement("div");
    toast.className = `toast ${type}`;
    toast.textContent = message;
    elements.toastRegion.append(toast);
    window.setTimeout(() => toast.remove(), 6000);
  }

  async function request(url, options) {
    let response;
    try {
      response = await fetch(`${API_BASE}${url}`, options);
    } catch {
      throw new Error("Cannot reach the local Python service. Start it with `python app.py` and try again.");
    }
    const payload = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(payload.error || `Request failed (${response.status}).`);
    return payload;
  }

  async function checkHealth() {
    const indicator = $("#connection-indicator");
    const label = $("#connection-label");
    try {
      await request("/api/health");
      indicator.classList.add("online");
      label.textContent = "API connected";
    } catch {
      indicator.classList.add("offline");
      label.textContent = "API offline";
    }
  }

  function setTrainingBusy(isBusy, message) {
    elements.train.disabled = isBusy || !state.file;
    elements.overlay.classList.toggle("hidden", !isBusy);
    if (message) elements.loadingMessage.textContent = message;
    elements.train.querySelector(".button-label").textContent = isBusy ? "Training models…" : "Train & evaluate models";
  }

  function targetCounts(target) {
    const option = state.targetOptions.find((item) => item.name === target);
    return option ? option.counts : {};
  }

  function renderInspection(data) {
    state.columns = data.columns;
    state.targetOptions = data.target_options;
    $("#upload-title").textContent = data.filename;
    $("#upload-help").textContent = "Dataset inspected successfully";
    $("#dataset-stat").textContent = data.filename.length > 19 ? `${data.filename.slice(0, 16)}…` : data.filename;
    $("#row-count").textContent = number(data.rows);
    $("#column-count").textContent = number(data.columns.length);
    $("#missing-count").textContent = number(data.missing_values);
    $("#duplicate-count").textContent = number(data.duplicate_rows);
    $("#feature-types").textContent = `${number(data.numeric_columns)} / ${number(data.categorical_columns)}`;
    $("#dataset-details").classList.remove("hidden");

    elements.target.replaceChildren();
    for (const option of state.targetOptions) {
      const item = document.createElement("option");
      item.value = option.name;
      item.textContent = `${option.name} (${Object.entries(option.counts).map(([label, count]) => `${label}: ${number(count)}`).join(", ")})`;
      elements.target.append(item);
    }
    elements.target.disabled = !state.targetOptions.length;
    elements.sampleSize.disabled = false;
    if (state.targetOptions.length) {
      elements.target.value = data.recommended_target || state.targetOptions[0].name;
      renderClassPreview(elements.target.value);
      state.target = elements.target.value;
      elements.train.disabled = false;
      elements.train.querySelector(".button-label").textContent = "Train & evaluate models";
    } else {
      elements.train.disabled = true;
      elements.train.querySelector(".button-label").textContent = "No supported target column found";
    }
  }

  function renderClassPreview(target) {
    const counts = targetCounts(target);
    const preview = $("#class-preview");
    preview.replaceChildren();
    const total = Object.values(counts).reduce((sum, count) => sum + count, 0);
    for (const [label, count] of Object.entries(counts)) {
      const chip = document.createElement("span");
      chip.className = `class-chip ${label === "Normal" ? "normal-chip" : "attack-chip"}`;
      chip.textContent = `${label}: ${number(count)} (${total ? (count / total * 100).toFixed(1) : 0}%)`;
      preview.append(chip);
    }
    if (total) {
      const distribution = document.createElement("div");
      distribution.className = "distribution-bar";
      distribution.setAttribute("aria-label", "Normal and malicious class distribution");
      const normal = document.createElement("span");
      normal.className = "distribution-normal";
      normal.style.width = `${(counts.Normal / total) * 100}%`;
      const attack = document.createElement("span");
      attack.className = "distribution-attack";
      attack.style.width = `${(counts.Malicious / total) * 100}%`;
      distribution.append(normal, attack);
      preview.append(distribution);
      const ratio = Math.max(counts.Normal, counts.Malicious) / Math.max(1, Math.min(counts.Normal, counts.Malicious));
      const note = document.createElement("span");
      note.className = "balance-note";
      note.textContent = ratio >= 1.5 ? `Class imbalance detected · ${ratio.toFixed(1)}:1 majority-to-minority` : "Class distribution is relatively balanced";
      preview.append(note);
    }
    renderNumericSummary(state.numericSummary);
  }

  function renderNumericSummary(summaries) {
    const container = $("#numeric-summary");
    container.classList.toggle("hidden", !summaries || !summaries.length);
    if (!summaries || !summaries.length) {
      container.replaceChildren();
      return;
    }
    const rows = summaries.map((item) => `
      <tr><td title="${escapeHtml(item.name)}">${escapeHtml(item.name)}</td>
      <td>${number(item.min)}</td><td>${number(item.median)}</td><td>${number(item.max)}</td></tr>`).join("");
    container.innerHTML = `<div class="numeric-summary-title">NUMERIC FEATURE SNAPSHOT · MIN / MEDIAN / MAX</div>
      <table><thead><tr><th>Feature</th><th>Min</th><th>Median</th><th>Max</th></tr></thead><tbody>${rows}</tbody></table>`;
  }

  async function inspectFile(file) {
    if (!file) return;
    if (!file.name.toLowerCase().endsWith(".csv")) {
      showToast("Choose a CSV file to inspect.");
      return;
    }
    if (file.size > 200 * 1024 * 1024) {
      showToast("The CSV is larger than the 200 MB upload limit.");
      return;
    }
    state.file = file;
    state.trained = false;
    $("#empty-results").classList.remove("hidden");
    $("#results-content").classList.add("hidden");
    $("#result-status").innerHTML = '<span class="status-dot"></span> Awaiting training';
    $("#records-stat").textContent = "—";
    $("#best-f1-stat").textContent = "—";
    $("#best-model-stat").textContent = "Train a model to see results";
    $("#prediction-form").classList.add("hidden");
    $("#prediction-empty").classList.remove("hidden");
    $("#prediction-model-label").innerHTML = '<span class="tiny-shield">◆</span> Train a model to enable prediction';
    elements.train.disabled = true;
    elements.train.querySelector(".button-label").textContent = "Inspecting dataset…";
    try {
      const body = new FormData();
      body.append("file", file);
      const inspected = await request("/api/inspect", { method: "POST", body });
      state.numericSummary = inspected.numeric_summary;
      renderInspection(inspected);
    } catch (error) {
      state.file = null;
      $("#upload-title").textContent = "Drop your CSV here";
      $("#upload-help").textContent = "or browse files · up to 200 MB";
      showToast(error.message);
    } finally {
      if (!state.file) elements.train.querySelector(".button-label").textContent = "Inspect a dataset to begin";
    }
  }

  function metricCell(value) {
    return `<td>${percent(value)}</td>`;
  }

  function renderResults(report) {
    $("#empty-results").classList.add("hidden");
    $("#results-content").classList.remove("hidden");
    $("#result-status").innerHTML = '<span class="status-dot online"></span> Training complete';
    $("#records-stat").textContent = number(report.sampled_records);
    $("#best-f1-stat").textContent = percent(report.best_f1);
    $("#best-model-stat").textContent = `${report.best_model} · attack-class F1`;
    $("#models-stat").innerHTML = `03 <span class="stat-sub">classifiers</span>`;
    $("#results-description").textContent = `${number(report.test_records)} held-out test records · ${number(report.sampled_records)} sampled records total`;
    $("#prediction-model-label").innerHTML = `<span class="tiny-shield">◆</span> Best model: ${escapeHtml(report.best_model)}`;

    const ordered = [...report.models].sort((a, b) => b.cv_f1_mean - a.cv_f1_mean);
    $("#comparison-body").innerHTML = ordered.map((model, index) => `
      <tr class="${index === 0 ? "best-row" : ""}">
        <td>${escapeHtml(model.name)}${index === 0 ? '<span class="best-tag">BEST</span>' : ""}</td>
        <td>${percent(model.cv_f1_mean)} <span class="th-muted">± ${percent(model.cv_f1_std)}</span></td>
        ${metricCell(model.accuracy)}${metricCell(model.precision)}${metricCell(model.recall)}${metricCell(model.f1)}
        <td>${index === 0 ? "Selected" : ""}</td>
      </tr>`).join("");

    $("#model-details").innerHTML = report.models.map((model) => {
      const matrix = model.confusion_matrix;
      const normalReport = model.classification_report["Normal Traffic"];
      const attackReport = model.classification_report["Malicious Traffic"];
      const params = Object.entries(model.best_params).map(([key, value]) => `${key}: ${JSON.stringify(value)}`).join(" · ") || "Default settings";
      return `<article class="model-card">
        <h4>${escapeHtml(model.name)} <span>CV F1 ${percent(model.cv_f1_mean)}</span></h4>
        <p><strong>${report.cv_folds} validation folds:</strong></p>
        <p class="fold-scores">${model.cv_f1_folds.map(percent).join(" · ")}</p>
        <p><strong>Best settings:</strong> ${escapeHtml(params)}</p>
        <p><strong>Confusion matrix</strong> · rows = actual, columns = predicted (normal, attack):</p>
        <p><strong>Normal:</strong> ${number(matrix[0][0])} correctly classified · ${number(matrix[0][1])} false alarms</p>
        <p><strong>Attack:</strong> ${number(matrix[1][1])} detected · ${number(matrix[1][0])} missed</p>
        <p><strong>Class report (P / R / F1):</strong> Normal ${percent(normalReport.precision)} / ${percent(normalReport.recall)} / ${percent(normalReport["f1-score"])}</p>
        <p><strong>Malicious:</strong> ${percent(attackReport.precision)} / ${percent(attackReport.recall)} / ${percent(attackReport["f1-score"])}</p>
      </article>`;
    }).join("");
    renderPredictionForm(report.feature_info);
  }

  function renderPredictionForm(features) {
    const form = $("#prediction-form");
    const grid = $("#feature-grid");
    grid.replaceChildren();
    for (const feature of features) {
      const wrapper = document.createElement("div");
      wrapper.className = "feature-field";
      const label = document.createElement("label");
      label.htmlFor = `feature-${feature.name}`;
      label.textContent = feature.name;
      const input = document.createElement("input");
      input.className = "feature-control";
      input.id = `feature-${feature.name}`;
      input.name = feature.name;
      input.autocomplete = "off";
      input.placeholder = feature.kind === "numeric" ? "Enter a number" : "Enter a category";
      if (feature.kind === "numeric") {
        input.type = "number";
        input.step = "any";
      } else {
        input.type = "text";
        if (feature.categories.length) {
          const listId = `options-${feature.name}`;
          const datalist = document.createElement("datalist");
          datalist.id = listId;
          for (const category of feature.categories) {
            const option = document.createElement("option");
            option.value = category;
            datalist.append(option);
          }
          input.setAttribute("list", listId);
          wrapper.append(label, input, datalist);
          grid.append(wrapper);
          continue;
        }
      }
      wrapper.append(label, input);
      grid.append(wrapper);
    }
    $("#prediction-empty").classList.add("hidden");
    form.classList.remove("hidden");
  }

  async function train() {
    if (!state.file || !elements.target.value) return;
    setTrainingBusy(true, "Sampling rows, splitting the data, and building preprocessing pipelines…");
    elements.train.querySelector(".button-label").textContent = "Training models…";
    $("#result-status").innerHTML = '<span class="status-dot"></span> Training in progress';
    try {
      const body = new FormData();
      body.append("file", state.file);
      body.append("target", elements.target.value);
      body.append("max_samples", elements.sampleSize.value);
      const report = await request("/api/train", { method: "POST", body });
      state.trained = true;
      state.target = elements.target.value;
      renderResults(report);
      showToast(`Training complete. ${report.best_model} selected by attack-class F1.`, "success");
      $("#results").scrollIntoView({ behavior: "smooth", block: "start" });
    } catch (error) {
      $("#result-status").innerHTML = '<span class="status-dot"></span> Training failed';
      showToast(error.message);
    } finally {
      setTrainingBusy(false);
    }
  }

  async function predict(event) {
    event.preventDefault();
    if (!state.trained) return;
    const record = {};
    for (const [name, rawValue] of new FormData(event.currentTarget).entries()) {
      if (rawValue === "") continue;
      const field = state.columns.find((item) => item.name === name);
      if (field && field.kind === "numeric") {
        const parsed = Number(rawValue);
        if (!Number.isFinite(parsed)) {
          showToast(`${name} must be a valid number.`);
          return;
        }
        record[name] = parsed;
      } else {
        record[name] = rawValue;
      }
    }
    const button = $("#predict-button");
    button.disabled = true;
    button.firstChild.textContent = "Classifying… ";
    try {
      const result = await request("/api/predict", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ features: record })
      });
      const output = $("#prediction-output");
      output.className = `prediction-output ${result.prediction === 1 ? "malicious" : "normal"}`;
      output.innerHTML = `<div class="output-shield">${result.prediction === 1 ? "!" : "✓"}</div>
        <strong>${escapeHtml(result.label)}</strong>
        <p>${result.prediction === 1 ? "The trained model classified this record as malicious traffic." : "The trained model classified this record as normal traffic."}</p>
        ${result.confidence === null ? "" : `<span class="confidence">Confidence · ${percent(result.confidence)}</span>`}`;
    } catch (error) {
      showToast(error.message);
    } finally {
      button.disabled = false;
      button.firstChild.textContent = "Classify record ";
    }
  }

  elements.file.addEventListener("change", (event) => inspectFile(event.target.files[0]));
  elements.dropZone.addEventListener("dragover", (event) => { event.preventDefault(); elements.dropZone.classList.add("dragover"); });
  elements.dropZone.addEventListener("dragleave", () => elements.dropZone.classList.remove("dragover"));
  elements.dropZone.addEventListener("drop", (event) => {
    event.preventDefault();
    elements.dropZone.classList.remove("dragover");
    inspectFile(event.dataTransfer.files[0]);
  });
  elements.target.addEventListener("change", () => {
    state.target = elements.target.value;
    renderClassPreview(state.target);
  });
  elements.train.addEventListener("click", train);
  $("#prediction-form").addEventListener("submit", predict);
  $("#prediction-form").addEventListener("reset", () => {
    window.setTimeout(() => {
      const output = $("#prediction-output");
      output.className = "prediction-output empty-output";
      output.innerHTML = '<div class="output-shield">◇</div><strong>Waiting for input</strong><p>Submit a network record to see the classifier\\u0027s prediction.</p>';
    }, 0);
  });
  document.querySelectorAll(".nav-link").forEach((link) => link.addEventListener("click", () => {
    document.querySelector(".nav-link.active")?.classList.remove("active");
    link.classList.add("active");
  }));
  checkHealth();
})();